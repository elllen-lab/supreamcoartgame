import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';

import { AppController } from './app.controller';
import { AppService } from './app.service';

import { PrismaModule } from './prisma/prisma.module';

import { UsersModule } from './users/users.module';

import { CasesModule } from './cases/cases.module';

import { AuthModule } from './auth/auth.module';

import { DecisionsModule } from './decisions/decisions.module';

import { AuditModule } from './audit/audit.module';

import { JwtAuthGuard } from './auth/jwt-auth.guard';

import { RolesGuard } from './auth/roles.guard';

import { CasesController } from './cases/cases.controller';


@Module({

  imports: [

    ConfigModule.forRoot({

      isGlobal: true,

      envFilePath: '.env',

    }),


    PrismaModule,

    UsersModule,

    CasesModule,

    AuthModule,

    DecisionsModule,

    AuditModule,

  ],


  controllers: [
  CasesController,
    AppController,

  ],


  providers: [

    AppService,


    // Проверка JWT токена

    {

      provide: APP_GUARD,

      useClass: JwtAuthGuard,

    },


    // Проверка ролей

    {

      provide: APP_GUARD,

      useClass: RolesGuard,

    },


  ],


})

export class AppModule {}