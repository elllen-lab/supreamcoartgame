import {
  NestFactory,
} from '@nestjs/core';


import {
  AppModule,
} from './app.module';


import {
  ValidationPipe,
  Logger,
} from '@nestjs/common';


import {
  SwaggerModule,
  DocumentBuilder,
} from '@nestjs/swagger';


import cookieParser from 'cookie-parser';




async function bootstrap() {


const logger =
new Logger('San Andreas API');



const app =
await NestFactory.create(
  AppModule,
);




// ==========================
// Cookies
// ==========================


app.use(
  cookieParser(),
);





// ==========================
// CORS
// ==========================


app.enableCors({

  origin:
  'http://localhost:3000',

  credentials:true,

});





// ==========================
// Validation
// ==========================


app.useGlobalPipes(

new ValidationPipe({

  whitelist:true,

  forbidNonWhitelisted:true,

  transform:true,

})

);






// ==========================
// Swagger
// ==========================


const config =

new DocumentBuilder()

.setTitle(
'San Andreas Supreme Court API'
)

.setDescription(
'API Верховного суда штата San Andreas'
)

.setVersion(
'1.0.0'
)

.addCookieAuth(

'access_token',

{

type:'apiKey',

in:'cookie',

name:'access_token',

},

)

.build();





const document =

SwaggerModule.createDocument(

app,

config,

);





SwaggerModule.setup(

'api',

app,

document,

{

swaggerOptions:{

persistAuthorization:true,

},

},

);






// ==========================
// Server
// ==========================


await app.listen(
3001,
);



logger.log(
'================================='
);


logger.log(
'San Andreas Supreme Court API'
);


logger.log(
'Server running: http://localhost:3001'
);


logger.log(
'Swagger: http://localhost:3001/api'
);


logger.log(
'================================='
);



}



bootstrap();