import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';

import { Request } from 'express';
import { AuthService } from '../auth.service';


@Injectable()
export class AuthGuard implements CanActivate {

  constructor(
    private readonly authService: AuthService,
  ) {}


  async canActivate(
    context: ExecutionContext,
  ): Promise<boolean> {


    const request =
      context
        .switchToHttp()
        .getRequest<Request>();


    const token =
      request.cookies?.access_token;


    if (!token) {

      throw new UnauthorizedException(
        'JWT token missing',
      );

    }


    try {


      const payload =
        this.authService.verifyToken(token);



      request.user = payload;


      return true;


    } catch {


      throw new UnauthorizedException(
        'Invalid JWT token',
      );

    }

  }

}