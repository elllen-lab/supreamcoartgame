import {
  Injectable,
  ForbiddenException,
  ConflictException,
  NotFoundException,
} from '@nestjs/common';


import {
  CaseDecisionStatus,
  CaseStatus,
  Role,
} from '@prisma/client';


import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';



@Injectable()
export class DecisionsService {


constructor(

private readonly prisma: PrismaService,

private readonly audit: AuditService,

){}





// ===========================
// Создание решения судьёй
// ===========================

async createDecision(

caseId:string,

userId:string,

text:string,

role:Role,

){



if(role !== Role.JUDGE &&
   role !== Role.CHIEF_JUDGE &&
   role !== Role.SUPER_ADMIN
){

throw new ForbiddenException(
'Недостаточно прав',
);

}



const courtCase =
await this.prisma.case.findUnique({

where:{
id:caseId,
},

});



if(!courtCase){

throw new NotFoundException(
'Дело не найдено',
);

}




if(

role === Role.JUDGE &&

courtCase.judgeId !== userId

){

throw new ForbiddenException(
'Вы не назначены судьёй этого дела',
);

}




const exists =
await this.prisma.caseDecision.findUnique({

where:{
caseId,
},

});



if(exists){

throw new ConflictException(
'Решение уже существует',
);

}




const decision =
await this.prisma.caseDecision.create({

data:{


caseId,

judgeId:userId,

text,


status:
CaseDecisionStatus.PENDING,


},

});




await this.audit.create(

userId,

'CREATE_DECISION',

`Создано решение по делу ${caseId}`,

caseId,

);



return decision;


}







// ===========================
// Утверждение главным судьёй
// ===========================


async approveDecision(

caseId:string,

userId:string,

role:Role,

){


if(
role !== Role.CHIEF_JUDGE &&
role !== Role.SUPER_ADMIN
){

throw new ForbiddenException(
'Только главный судья может утверждать решения',
);

}



const decision =
await this.prisma.caseDecision.findUnique({

where:{
caseId,
},

});



if(!decision){

throw new NotFoundException(
'Решение не найдено',
);

}




const updated =
await this.prisma.caseDecision.update({

where:{
caseId,
},


data:{


status:
CaseDecisionStatus.APPROVED,


approvedById:userId,


approvedAt:
new Date(),


},


});




await this.audit.create(

userId,

'APPROVE_DECISION',

`Утверждено решение дела ${caseId}`,

caseId,

);



return updated;


}









// ===========================
// Публикация решения
// ===========================


async publishDecision(

caseId:string,

userId:string,

role:Role,

){



if(role !== Role.SUPER_ADMIN){

throw new ForbiddenException(
'Только администратор может публиковать решения',
);

}



const decision =
await this.prisma.caseDecision.findUnique({

where:{
caseId,
},

});



if(!decision){

throw new NotFoundException(
'Решение не найдено',
);

}




if(

decision.status !== 
CaseDecisionStatus.APPROVED

){

throw new ConflictException(
'Сначала требуется утверждение',
);

}




const updated =

await this.prisma.$transaction([


this.prisma.caseDecision.update({

where:{
caseId,
},

data:{


status:
CaseDecisionStatus.PUBLISHED,

},


}),



this.prisma.case.update({

where:{
id:caseId,
},

data:{


status:
CaseStatus.CLOSED,


publishedAt:
new Date(),

},


}),



]);





await this.audit.create(

userId,

'PUBLISH_DECISION',

`Опубликовано решение дела ${caseId}`,

caseId,

);



return updated[0];


}



}