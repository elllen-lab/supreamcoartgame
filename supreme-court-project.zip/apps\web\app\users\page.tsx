"use client";

import {
  useEffect,
  useState,
} from "react";

import ProtectedRoute from "../components/ProtectedRoute";
import Sidebar from "../components/Sidebar";


export default function UsersPage() {


  const [users,setUsers] =
    useState<any[]>([]);


  const [currentUser,setCurrentUser] =
    useState<any>(null);



  const [form,setForm] =
    useState({
      discordId:"",
      username:"",
    });




  async function loadUsers(){

    const res =
      await fetch(
        "http://localhost:3001/users",
        {
          credentials:"include",
        }
      );


    const data =
      await res.json();


    setUsers(data);

  }






  useEffect(()=>{


    async function load(){

      const me =
        await fetch(
          "http://localhost:3001/auth/me",
          {
            credentials:"include",
          }
        );


      const meData =
        await me.json();


      setCurrentUser(
        meData.user
      );


      loadUsers();

    }


    load();


  },[]);






  async function createUser(){


    const res =
      await fetch(
        "http://localhost:3001/users",
        {
          method:"POST",

          headers:{
            "Content-Type":
              "application/json",
          },

          credentials:"include",

          body:
            JSON.stringify(form),
        }
      );



    if(res.ok){

      alert(
        "Пользователь создан"
      );


      setForm({
        discordId:"",
        username:"",
      });


      loadUsers();


    }
    else{

      alert(
        "Ошибка создания пользователя"
      );

    }


  }






  async function changeRole(
    id:string,
    role:string
  ){


    const res =
      await fetch(
        `http://localhost:3001/users/${id}/role`,
        {
          method:"PATCH",

          headers:{
            "Content-Type":
              "application/json",
          },

          credentials:"include",

          body:
            JSON.stringify({
              role,
            }),
        }
      );



    if(res.ok){

      alert(
        "Роль изменена"
      );


      loadUsers();

    }
    else{

      alert(
        "Ошибка изменения роли"
      );

    }


  }







return (

<ProtectedRoute>


<div
style={{
display:"flex",
minHeight:"100vh"
}}
>


{
currentUser &&

<Sidebar
role={currentUser.role}
/>

}



<main
style={{
padding:"40px",
width:"100%"
}}
>


<h1>
Пользователи
</h1>





<div
style={{
background:"#fff",
padding:"20px",
border:"1px solid #ddd",
borderRadius:"10px",
marginBottom:"30px",
}}
>


<h2>
Создать пользователя
</h2>



<input

placeholder="Discord ID"

value={form.discordId}

onChange={(e)=>
setForm({
...form,
discordId:e.target.value
})
}

/>


<br/><br/>



<input

placeholder="Имя пользователя"

value={form.username}

onChange={(e)=>
setForm({
...form,
username:e.target.value
})
}

/>


<br/><br/>



<button
onClick={createUser}
>

Создать

</button>



</div>







{
users.map((user)=>(


<div

key={user.id}

style={{
border:"1px solid #ddd",
padding:"20px",
marginTop:"15px",
borderRadius:"10px",
background:"#fff",
}}

>


<h2>
{user.username}
</h2>



<p>
Discord:
<br/>
{user.discordId}
</p>




<p>
Текущая роль:

<b>
{" "}
{user.role}
</b>

</p>





<select

value={user.role}

onChange={(e)=>
changeRole(
user.id,
e.target.value
)
}

>


<option value="USER">
USER
</option>


<option value="LAWYER">
LAWYER
</option>


<option value="JUDGE">
JUDGE
</option>


<option value="CHIEF_JUDGE">
CHIEF_JUDGE
</option>


<option value="SUPER_ADMIN">
SUPER_ADMIN
</option>


</select>



</div>


))
}





</main>


</div>


</ProtectedRoute>

);


}