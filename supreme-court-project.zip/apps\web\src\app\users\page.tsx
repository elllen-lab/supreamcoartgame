"use client";

import {useEffect,useState} from "react";


export default function Users(){


const [users,setUsers]=useState<any[]>([]);


useEffect(()=>{

fetch(
"http://localhost:3001/users",
{
credentials:"include"
}
)
.then(r=>r.json())
.then(setUsers);


},[]);



return (

<div>

<h1>
Пользователи суда
</h1>


{
users.map(user=>(

<div key={user.id}>


<h3>
{user.username}
</h3>


<p>
Discord:
{user.discordId}
</p>


<p>
Роль:
{user.role}
</p>


<hr/>

</div>


))
}


</div>


)


}