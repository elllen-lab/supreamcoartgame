"use client";

import { useEffect, useState } from "react";

export default function CasesPage(){

const [cases,setCases]=useState<any[]>([]);


useEffect(()=>{

fetch("http://localhost:3001/cases",{
credentials:"include"
})
.then(res=>res.json())
.then(data=>setCases(data));

},[]);



return (

<div>

<h1>
Дела Верховного суда San Andreas
</h1>


{
cases.map((item)=>(

<div 
key={item.id}
style={{
border:"1px solid #ccc",
padding:"15px",
margin:"10px"
}}
>


<h3>
{item.title}
</h3>


<p>
Автор:
{item.author?.username}
</p>


<p>
Судья:
{item.judge?.username || "Не назначен"}
</p>


<p>
Статус:
{item.status}
</p>


</div>

))
}


</div>


)

}