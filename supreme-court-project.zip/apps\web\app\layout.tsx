import "./globals.css";
import { AuthProvider } from "./providers/AuthProvider";

export const metadata = {
  title: "Supreme Court",
  description: "San Andreas Supreme Court",
};


export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {

  return (

    <html lang="ru">

      <body>

        <AuthProvider>

          {children}

        </AuthProvider>

      </body>

    </html>

  );

}