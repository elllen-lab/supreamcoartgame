import Link from "next/link";


export default function DashboardLayout({
children
}:{
children:React.ReactNode
}){


return (

<div>


<nav>

<Link href="/dashboard">
Главная
</Link>

<br/>


<Link href="/cases">
Дела
</Link>


<br/>


<Link href="/users">
Пользователи
</Link>


<br/>


<Link href="/audit">
Аудит
</Link>


</nav>


<hr/>


{children}


</div>

)

}