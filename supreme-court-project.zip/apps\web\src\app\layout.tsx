import "./globals.css";

export const metadata = {
  title: "Supreme Court",
  description: "San Andreas Supreme Court",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}