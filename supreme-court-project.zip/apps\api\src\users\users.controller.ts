import {
Controller,
Get,
} from '@nestjs/common';


import {
PrismaService,
} from '../prisma/prisma.service';



@Controller('users')

export class UsersController {


constructor(

private readonly prisma:PrismaService,

){}




@Get('judges')

async getJudges(){



return this.prisma.user.findMany({



where:{


role:'JUDGE'


},



select:{


id:true,

username:true,

discordId:true,


},



});



}


}