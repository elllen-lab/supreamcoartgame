import {
  Controller,
  Post,
  Patch,
  Param,
  Body,
  Req,
  ForbiddenException,
} from '@nestjs/common';

import {
  DecisionsService,
} from './decisions.service';

import {
  ApiTags,
  ApiBearerAuth,
  ApiBody,
} from '@nestjs/swagger';

import {
  Role,
} from '@prisma/client';

import {
  CreateDecisionDto,
} from './dto/create-decision.dto';



@ApiTags('Decisions')
@ApiBearerAuth()
@Controller()
export class DecisionsController {


  constructor(
    private readonly decisionsService: DecisionsService,
  ) {}



  // =====================================
  // Создание решения судьёй
  // =====================================


  @Post('cases/:id/decision')
  @ApiBody({
    type: CreateDecisionDto,
  })
  async createDecision(


    @Param('id')
    caseId:string,


    @Body()
    dto:CreateDecisionDto,


    @Req()
    req:any,


  ){


    if(
      req.user.role !== Role.JUDGE
    ){

      throw new ForbiddenException(
        'Только судья может вынести решение',
      );

    }



    return this.decisionsService.createDecision(

  caseId,

  dto.text,

  req.user.id,

  req.user.role,

);


  }







  // =====================================
  // Одобрение решения главным судьёй
  // =====================================


  @Patch('cases/:id/decision/approve')
  async approveDecision(


    @Param('id')
    caseId:string,


    @Req()
    req:any,


  ){



    if(

      req.user.role !== Role.CHIEF_JUDGE &&

      req.user.role !== Role.SUPER_ADMIN

    ){

      throw new ForbiddenException(

        'Недостаточно прав для утверждения решения',

      );

    }





    return this.decisionsService.approveDecision(

  caseId,

  req.user.id,

  req.user.role,

);



  }


}